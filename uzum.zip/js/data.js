export let pokemonCards = [
  {
    id: 1,
    title: "Erkaklar shimlari, tekis chinos, klassik",
    img: "https://picsum.photos/200",
    comment: " 4.5 (Sharh) ",
    categories: "Ma'lumot uchun matn",
    monthlyPay: "1400 so'm/oy",
    realPrize: 1569000,
    discountPrice: 142000,
    isFavourite: false,
  },
  {
    id: 2,
    title: "Ikki kamerali muzlatgich Biryusa M120, hajmi 205 l",

    img: "https://picsum.photos/200",
    comment: " 4.5 (Sharh) ",

    categories: "Ma'lumot uchun matn",
    monthlyPay: "1400 so'm/oy",
    realPrize: 1569000,
    discountPrice: 142000,
    isFavourite: false,
  },
  {
    id: 3,
    title: "Svetocopy ECO varaq qog'ozi, A4f, 80g/m2, 500 varaq",

    img: "https://picsum.photos/200",
    comment: " 4.5 (Sharh) ",

    categories: "Ma'lumot uchun matn",
    monthlyPay: "1400 so'm/oy",
    realPrize: 1569000,
    discountPrice: 142000,
    isFavourite: false,
  },
  {
    id: 4,
    title: "Fairy idish yuvish uchun suyuqlik, limon, 450 ml",

    img: "https://picsum.photos/200",
    comment: " 4.5 (Sharh) ",

    categories: "Ma'lumot uchun matn",
    monthlyPay: "1400 so'm/oy",
    realPrize: 1569000,
    discountPrice: 142000,
    isFavourite: false,
  },
  {
    id: 5,
    title: `Kir yuvish kukuni Oila tanlovi "Sovuq tazelik", qo'lda yuvish, 450 gr`,

    img: "https://picsum.photos/200",
    comment: " 4.5 (Sharh) ",

    categories: "Ma'lumot uchun matn",
    monthlyPay: "1400 so'm/oy",
    realPrize: 1569000,
    discountPrice: 142000,
    isFavourite: false,
  },
  {
    id: 6,
    title: "Erkaklar banan jinsi, F17",

    img: "https://picsum.photos/200",
    comment: " 4.5 (Sharh) ",

    categories: "Ma'lumot uchun matn",
    monthlyPay: "1400 so'm/oy",
    realPrize: 1569000,
    discountPrice: 142000,
    isFavourite: false,
  },
  {
    id: 7,
    title: "Sun & Moon",

    img: "https://picsum.photos/200",
    comment: " 4.5 (Sharh) ",

    categories: "Ma'lumot uchun matn",
    monthlyPay: "1400 so'm/oy",
    realPrize: 1569000,
    discountPrice: 142000,
    isFavourite: false,
  },
  {
    id: 8,
    title: "Brilliant Stars",

    img: "https://picsum.photos/200",
    comment: " 4.5 (Sharh) ",

    categories: "Ma'lumot uchun matn",
    monthlyPay: "1400 so'm/oy",
    realPrize: 1569000,
    discountPrice: 142000,
    isFavourite: false,
  },
];
